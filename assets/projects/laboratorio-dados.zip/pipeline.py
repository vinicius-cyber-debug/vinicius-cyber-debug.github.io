"""Laboratório demonstrativo: CSV sintético -> ETL Python -> SQLite/SQL -> JSON e CSV.
Executar com Python 3. Usa somente a biblioteca padrão. Não contém dados reais.
"""
import csv, json, sqlite3
from pathlib import Path
from decimal import Decimal
from datetime import date

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'output'
OUT.mkdir(exist_ok=True)
fields = ['id','data','canal','quantidade','preco_unitario','custo_unitario','status']
raw = []
for month in (7,8,9):
    for ci, channel in enumerate(('Loja','Online','Representante')):
        for i in range(1,21):
            raw.append([len(raw)+1,f'2026-{month:02d}-{i:02d}',channel,1+(i%4),f'{100+ci*15+i*2},00',f'{65+ci*5+i},00','Cancelada' if i%10==0 else 'Concluida'])
raw.append(raw[0].copy())
raw.append([999,'2026-09-01','Online',2,'valor inválido','50,00','Concluida'])
with (ROOT/'vendas-origem.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f);w.writerow(fields);w.writerows(raw)
seen=set();clean=[];duplicates=invalid=0
with (ROOT/'vendas-origem.csv').open(encoding='utf-8') as f:
    for row in csv.DictReader(f):
        try:
            id_=int(row['id']);day=date.fromisoformat(row['data']);qty=int(row['quantidade'])
            price=int(Decimal(row['preco_unitario'].replace(',','.'))*100)
            cost=int(Decimal(row['custo_unitario'].replace(',','.'))*100)
            assert qty>0 and price>=0 and cost>=0
            assert row['canal'] in ('Loja','Online','Representante')
            assert row['status'] in ('Cancelada','Concluida')
        except (ValueError,ArithmeticError,AssertionError):
            invalid+=1;continue
        if id_ in seen:
            duplicates+=1;continue
        seen.add(id_);clean.append((id_,str(day),row['canal'],qty,price,cost,row['status']))
db=sqlite3.connect(':memory:')
db.execute('CREATE TABLE vendas (id INTEGER PRIMARY KEY,data TEXT,canal TEXT,quantidade INTEGER,preco_centavos INTEGER,custo_centavos INTEGER,status TEXT)')
db.executemany('INSERT INTO vendas VALUES (?,?,?,?,?,?,?)',clean)
query='''SELECT canal,COUNT(*) AS pedidos,SUM(quantidade*preco_centavos) AS receita_centavos,
SUM(quantidade*(preco_centavos-custo_centavos)) AS lucro_bruto_centavos
FROM vendas WHERE status='Concluida' AND (?='todos' OR substr(data,1,7)=?) GROUP BY canal ORDER BY receita_centavos DESC'''
(ROOT/'consultas.sql').write_text('-- Parâmetros: período ou todos, repetido duas vezes. Valores monetários em centavos.\n'+query+';\n',encoding='utf-8')
periods=[]
for period in ['todos','2026-07','2026-08','2026-09']:
    channels=[]
    for channel,orders,revenue,profit in db.execute(query,(period,period)):
        channels.append(dict(canal=channel,pedidos=orders,receita_centavos=revenue,lucro_bruto_centavos=profit,margem_pct=round(100*profit/revenue,2)))
    total=sum(c['receita_centavos'] for c in channels);profit=sum(c['lucro_bruto_centavos'] for c in channels)
    best=max(channels,key=lambda c:c['margem_pct'])
    periods.append(dict(periodo=period,receita_centavos=total,lucro_bruto_centavos=profit,margem_pct=round(100*profit/total,2),pedidos=sum(c['pedidos'] for c in channels),canais=channels,conclusao=f"Na amostra sintética deste período, {best['canal']} apresenta a maior margem bruta ({best['margem_pct']:.2f}%). A conclusão descreve apenas este conjunto de demonstração."))
assert len(clean)==180 and duplicates==1 and invalid==1
assert periods[0]['pedidos']==162
assert periods[0]['receita_centavos']==sum(p['receita_centavos'] for p in periods[1:])
assert periods[0]['lucro_bruto_centavos']==sum(p['lucro_bruto_centavos'] for p in periods[1:])
result=dict(pergunta='Qual canal combina faturamento e margem bruta?',origem='Dados sintéticos gerados pelo próprio pipeline; nenhum registro de empresa real.',qualidade=dict(extraidos=len(raw),validos=len(clean),duplicados_removidos=duplicates,invalidos_rejeitados=invalid),periodos=periods)
(OUT/'indicadores.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
with (OUT/'vendas-tratadas.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f);w.writerow(['id','data','canal','quantidade','preco_centavos','custo_centavos','status']);w.writerows(clean)
(OUT/'validacao.json').write_text(json.dumps(dict(status='aprovado',verificacoes=['Contagem de linhas válidas','Remoção de uma duplicata','Rejeição de valor monetário inválido','162 pedidos concluídos','Reconciliação de receita e lucro mensal com total'],**result['qualidade']),ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result['qualidade'],ensure_ascii=False))
