-- Parâmetros: período ou todos, repetido duas vezes. Valores monetários em centavos.
SELECT canal,COUNT(*) AS pedidos,SUM(quantidade*preco_centavos) AS receita_centavos,
SUM(quantidade*(preco_centavos-custo_centavos)) AS lucro_bruto_centavos
FROM vendas WHERE status='Concluida' AND (?='todos' OR substr(data,1,7)=?) GROUP BY canal ORDER BY receita_centavos DESC;
