# Laboratório SQL + ETL + análise de canais

Estudo demonstrativo criado para o portfólio de Vinicius Maia com assistência de IA. Não representa projeto de cliente, experiência de produção ou resultado financeiro real.

Pergunta: qual canal combina faturamento e margem bruta?

## Reproduzir

Execute `python pipeline.py`. Usa apenas a biblioteca padrão do Python 3. O script cria uma origem sintética, remove duplicatas, rejeita valores inválidos, normaliza moeda em centavos, carrega SQLite em memória e calcula agregações SQL. Os resultados ficam em `output/`.

Definições: faturamento = quantidade × preço nos pedidos concluídos; lucro bruto = quantidade × (preço − custo); margem bruta = lucro bruto / faturamento. Pedidos cancelados não entram na receita. Não são considerados impostos, frete, devoluções ou despesas operacionais. Não interpretar lucro bruto como lucro líquido.

## Validação

O pipeline verifica contagem e qualidade da carga e reconcilia receita/lucro dos meses com o período total. Consulte `output/validacao.json` e `consultas.sql`. As conclusões são calculadas para cada período, sem valores digitados manualmente no painel.

## Power BI — preparação, ainda sem relatório validado

Importe `output/vendas-tratadas.csv`, defina data como Data e os campos de centavos/quantidade como Número inteiro. As medidas propostas estão em `medidas.dax`. Crie cartões de receita e margem, gráfico por canal e filtro de data. Compare os resultados com `output/indicadores.json`. Esta etapa ainda não foi executada no Power BI; não existe arquivo PBIX neste pacote.
