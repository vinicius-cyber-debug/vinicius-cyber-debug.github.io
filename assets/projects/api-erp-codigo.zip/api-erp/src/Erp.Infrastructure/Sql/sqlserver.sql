-- Run against an existing database. No objects or data are dropped.
IF OBJECT_ID(N'dbo.Customers', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Customers (
        Id INT NOT NULL CONSTRAINT PK_Customers PRIMARY KEY CONSTRAINT CK_Customers_Id CHECK (Id > 0),
        Code NVARCHAR(40) NOT NULL CONSTRAINT UQ_Customers_Code UNIQUE CONSTRAINT CK_Customers_Code CHECK (LEN(LTRIM(RTRIM(Code))) > 0),
        Name NVARCHAR(200) NOT NULL CONSTRAINT CK_Customers_Name CHECK (LEN(LTRIM(RTRIM(Name))) > 0)
    );
END;

IF OBJECT_ID(N'dbo.Products', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Products (
        Id INT NOT NULL CONSTRAINT PK_Products PRIMARY KEY CONSTRAINT CK_Products_Id CHECK (Id > 0),
        Code NVARCHAR(40) NOT NULL CONSTRAINT UQ_Products_Code UNIQUE CONSTRAINT CK_Products_Code CHECK (LEN(LTRIM(RTRIM(Code))) > 0),
        Name NVARCHAR(200) NOT NULL CONSTRAINT CK_Products_Name CHECK (LEN(LTRIM(RTRIM(Name))) > 0),
        CurrentPriceCents BIGINT NOT NULL CONSTRAINT CK_Products_Price CHECK (CurrentPriceCents >= 0)
    );
END;

IF OBJECT_ID(N'dbo.Invoices', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Invoices (
        Id INT NOT NULL CONSTRAINT PK_Invoices PRIMARY KEY CONSTRAINT CK_Invoices_Id CHECK (Id > 0),
        Number NVARCHAR(40) NOT NULL CONSTRAINT CK_Invoices_Number CHECK (LEN(LTRIM(RTRIM(Number))) > 0),
        Series NVARCHAR(20) NOT NULL CONSTRAINT CK_Invoices_Series CHECK (LEN(LTRIM(RTRIM(Series))) > 0),
        IssuedOn DATE NOT NULL,
        Status NVARCHAR(20) NOT NULL CONSTRAINT CK_Invoices_Status CHECK (Status COLLATE Latin1_General_100_BIN2 IN (N'autorizada', N'cancelada', N'pendente')),
        CustomerId INT NOT NULL CONSTRAINT FK_Invoices_Customers REFERENCES dbo.Customers(Id),
        CONSTRAINT UQ_Invoices_Series_Number UNIQUE (Series, Number)
    );
END;

IF OBJECT_ID(N'dbo.InvoiceItems', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.InvoiceItems (
        Id INT NOT NULL CONSTRAINT PK_InvoiceItems PRIMARY KEY CONSTRAINT CK_InvoiceItems_Id CHECK (Id > 0),
        InvoiceId INT NOT NULL CONSTRAINT FK_InvoiceItems_Invoices REFERENCES dbo.Invoices(Id),
        Sequence INT NOT NULL CONSTRAINT CK_InvoiceItems_Sequence CHECK (Sequence > 0),
        ProductId INT NOT NULL CONSTRAINT FK_InvoiceItems_Products REFERENCES dbo.Products(Id),
        Quantity INT NOT NULL CONSTRAINT CK_InvoiceItems_Quantity CHECK (Quantity > 0),
        UnitPriceCents BIGINT NOT NULL CONSTRAINT CK_InvoiceItems_Price CHECK (UnitPriceCents >= 0),
        CONSTRAINT UQ_InvoiceItems_InvoiceId_Sequence UNIQUE (InvoiceId, Sequence)
    );
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Invoices') AND name = N'IX_Invoices_IssuedOn_Id')
    CREATE INDEX IX_Invoices_IssuedOn_Id ON dbo.Invoices (IssuedOn DESC, Id DESC);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Invoices') AND name = N'IX_Invoices_CustomerId_IssuedOn_Id')
    CREATE INDEX IX_Invoices_CustomerId_IssuedOn_Id ON dbo.Invoices (CustomerId, IssuedOn DESC, Id DESC);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Invoices') AND name = N'IX_Invoices_Status_IssuedOn_Id')
    CREATE INDEX IX_Invoices_Status_IssuedOn_Id ON dbo.Invoices (Status, IssuedOn DESC, Id DESC);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.InvoiceItems') AND name = N'IX_InvoiceItems_ProductId')
    CREATE INDEX IX_InvoiceItems_ProductId ON dbo.InvoiceItems (ProductId);
