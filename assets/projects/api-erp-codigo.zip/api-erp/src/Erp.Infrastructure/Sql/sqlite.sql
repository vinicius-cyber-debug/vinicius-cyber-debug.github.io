CREATE TABLE IF NOT EXISTS Customers (
    Id INTEGER NOT NULL PRIMARY KEY CHECK (Id > 0 AND Id <= 2147483647),
    Code TEXT NOT NULL UNIQUE CHECK (length(trim(Code)) > 0),
    Name TEXT NOT NULL CHECK (length(trim(Name)) > 0)
);

CREATE TABLE IF NOT EXISTS Products (
    Id INTEGER NOT NULL PRIMARY KEY CHECK (Id > 0 AND Id <= 2147483647),
    Code TEXT NOT NULL UNIQUE CHECK (length(trim(Code)) > 0),
    Name TEXT NOT NULL CHECK (length(trim(Name)) > 0),
    CurrentPriceCents INTEGER NOT NULL CHECK (typeof(CurrentPriceCents) = 'integer' AND CurrentPriceCents >= 0)
);

CREATE TABLE IF NOT EXISTS Invoices (
    Id INTEGER NOT NULL PRIMARY KEY CHECK (Id > 0 AND Id <= 2147483647),
    Number TEXT NOT NULL CHECK (length(trim(Number)) > 0),
    Series TEXT NOT NULL CHECK (length(trim(Series)) > 0),
    IssuedOn TEXT NOT NULL CHECK (
        length(IssuedOn) = 10
        AND IssuedOn GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'
        AND date(IssuedOn, '+0 days') IS NOT NULL
        AND date(IssuedOn, '+0 days') = IssuedOn
    ),
    Status TEXT NOT NULL CHECK (Status IN ('autorizada', 'cancelada', 'pendente')),
    CustomerId INTEGER NOT NULL REFERENCES Customers(Id),
    UNIQUE (Series, Number)
);

CREATE TABLE IF NOT EXISTS InvoiceItems (
    Id INTEGER NOT NULL PRIMARY KEY CHECK (Id > 0 AND Id <= 2147483647),
    InvoiceId INTEGER NOT NULL REFERENCES Invoices(Id),
    Sequence INTEGER NOT NULL CHECK (typeof(Sequence) = 'integer' AND Sequence > 0 AND Sequence <= 2147483647),
    ProductId INTEGER NOT NULL REFERENCES Products(Id),
    Quantity INTEGER NOT NULL CHECK (typeof(Quantity) = 'integer' AND Quantity > 0 AND Quantity <= 2147483647),
    UnitPriceCents INTEGER NOT NULL CHECK (typeof(UnitPriceCents) = 'integer' AND UnitPriceCents >= 0),
    UNIQUE (InvoiceId, Sequence)
);

CREATE INDEX IF NOT EXISTS IX_Invoices_IssuedOn_Id ON Invoices (IssuedOn DESC, Id DESC);
CREATE INDEX IF NOT EXISTS IX_Invoices_CustomerId_IssuedOn_Id ON Invoices (CustomerId, IssuedOn DESC, Id DESC);
CREATE INDEX IF NOT EXISTS IX_Invoices_Status_IssuedOn_Id ON Invoices (Status, IssuedOn DESC, Id DESC);
CREATE INDEX IF NOT EXISTS IX_InvoiceItems_ProductId ON InvoiceItems (ProductId);
