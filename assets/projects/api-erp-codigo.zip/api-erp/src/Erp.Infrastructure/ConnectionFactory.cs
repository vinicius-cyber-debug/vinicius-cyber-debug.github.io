using System.Data.Common;
using Microsoft.Data.SqlClient;
using Microsoft.Data.Sqlite;

namespace Erp.Infrastructure;

public sealed class ConnectionFactory(DatabaseSettings settings)
{
    public string Provider { get; } = NormalizeProvider(settings.Provider);

    public DbConnection Create() => Provider switch
    {
        // The provider applies this setting every time a connection is opened,
        // including a connection returned directly by Create().
        "SQLite" => new SqliteConnection(new SqliteConnectionStringBuilder(settings.ConnectionString)
        {
            ForeignKeys = true
        }.ToString()),
        "SqlServer" => new SqlConnection(settings.ConnectionString),
        _ => throw new InvalidOperationException("Provedor de banco de dados não suportado.")
    };

    public async Task<DbConnection> OpenAsync(CancellationToken cancellationToken)
    {
        var connection = Create();
        try
        {
            await connection.OpenAsync(cancellationToken);
            return connection;
        }
        catch
        {
            await connection.DisposeAsync();
            throw;
        }
    }

    private static string NormalizeProvider(string provider)
    {
        if (string.Equals(provider?.Trim(), "SQLite", StringComparison.OrdinalIgnoreCase)) return "SQLite";
        if (string.Equals(provider?.Trim(), "SqlServer", StringComparison.OrdinalIgnoreCase)) return "SqlServer";
        throw new ArgumentException("Use SQLite ou SqlServer em Database:Provider.", nameof(provider));
    }
}
