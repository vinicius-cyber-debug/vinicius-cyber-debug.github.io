using System.Data;
using System.Data.Common;
using System.Globalization;
using Dapper;
using Erp.Application;
using Microsoft.Data.Sqlite;

namespace Erp.Infrastructure;

public sealed class InvoiceRepository(ConnectionFactory factory) : IInvoiceRepository
{
    private const string InvoiceColumns = """
        i.Id, i.Number, i.Series, i.IssuedOn, i.Status,
        c.Id AS CustomerId, c.Code AS CustomerCode, c.Name AS CustomerName,
        COALESCE((SELECT SUM(CAST(item.Quantity AS BIGINT) * item.UnitPriceCents)
            FROM InvoiceItems item WHERE item.InvoiceId = i.Id), 0) AS TotalCents
        """;

    private const string InvoiceSource = "FROM Invoices i INNER JOIN Customers c ON c.Id = i.CustomerId";

    public async Task<PageDto<InvoiceDto>> ListAsync(InvoiceFilter filter, CancellationToken cancellationToken)
    {
        var (where, parameters) = BuildFilter(filter);
        parameters.Add("Offset", filter.Offset);
        parameters.Add("PageSize", filter.PageSize);
        var pagination = factory.Provider == "SQLite"
            ? "LIMIT @PageSize OFFSET @Offset"
            : "OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY";

        await using var connection = await factory.OpenAsync(cancellationToken);
        // Count and the page observe one consistent set of invoices.
        await using var transaction = await BeginReadTransactionAsync(connection, cancellationToken);
        var countExpression = factory.Provider == "SqlServer" ? "COUNT_BIG(*)" : "COUNT(*)";
        var count = await connection.ExecuteScalarAsync<long>(new CommandDefinition(
            $"SELECT {countExpression} {InvoiceSource} {where};", parameters, transaction,
            cancellationToken: cancellationToken));
        var rows = await connection.QueryAsync<InvoiceRow>(new CommandDefinition(
            $"SELECT {InvoiceColumns} {InvoiceSource} {where} ORDER BY i.IssuedOn DESC, i.Id DESC {pagination};",
            parameters, transaction, cancellationToken: cancellationToken));
        await transaction.CommitAsync(cancellationToken);
        return new PageDto<InvoiceDto>(rows.Select(ToDto).ToArray(), filter.Page, filter.PageSize, count);
    }

    public async Task<InvoiceDetailDto?> GetAsync(int id, CancellationToken cancellationToken)
    {
        await using var connection = await factory.OpenAsync(cancellationToken);
        await using var transaction = await BeginReadTransactionAsync(connection, cancellationToken);
        using var results = await connection.QueryMultipleAsync(new CommandDefinition($"""
            SELECT {InvoiceColumns} {InvoiceSource} WHERE i.Id = @Id;
            SELECT item.Id, item.Sequence, item.Quantity, item.UnitPriceCents,
                p.Id AS ProductId, p.Code AS ProductCode, p.Name AS ProductName
            FROM InvoiceItems item INNER JOIN Products p ON p.Id = item.ProductId
            WHERE item.InvoiceId = @Id ORDER BY item.Sequence, item.Id;
            """, new { Id = id }, transaction, cancellationToken: cancellationToken));
        var invoice = await results.ReadSingleOrDefaultAsync<InvoiceRow>();
        var itemRows = await results.ReadAsync<InvoiceItemRow>();
        await transaction.CommitAsync(cancellationToken);
        if (invoice is null) return null;
        var items = itemRows.Select(item => new InvoiceItemDto(item.Id, item.Sequence,
            new ItemProductDto(item.ProductId, item.ProductCode, item.ProductName), item.Quantity,
            item.UnitPriceCents / 100m, (item.UnitPriceCents / 100m) * item.Quantity)).ToArray();
        return new InvoiceDetailDto(invoice.Id, invoice.Number, invoice.Series,
            DateOnly.FromDateTime(invoice.IssuedOn), invoice.Status, ToCustomer(invoice),
            invoice.TotalCents / 100m, items);
    }

    public async Task<IReadOnlyList<CustomerDto>> CustomersAsync(CancellationToken cancellationToken)
    {
        await using var connection = await factory.OpenAsync(cancellationToken);
        var rows = await connection.QueryAsync<CustomerRow>(new CommandDefinition(
            "SELECT Id, Name, Code FROM Customers ORDER BY Name, Id;",
            cancellationToken: cancellationToken));
        return rows.Select(row => new CustomerDto(row.Id, row.Name, row.Code)).ToArray();
    }

    public async Task<IReadOnlyList<ProductDto>> ProductsAsync(CancellationToken cancellationToken)
    {
        await using var connection = await factory.OpenAsync(cancellationToken);
        var rows = await connection.QueryAsync<ProductRow>(new CommandDefinition(
            "SELECT Id, Code, Name, CurrentPriceCents FROM Products ORDER BY Name, Id;",
            cancellationToken: cancellationToken));
        return rows.Select(row => new ProductDto(row.Id, row.Code, row.Name, row.CurrentPriceCents / 100m)).ToArray();
    }

    public async Task<bool> IsAvailableAsync(CancellationToken cancellationToken)
    {
        await using var connection = await factory.OpenAsync(cancellationToken);
        return await connection.ExecuteScalarAsync<int>(new CommandDefinition("SELECT 1;",
            cancellationToken: cancellationToken)) == 1;
    }

    private static (string Where, DynamicParameters Parameters) BuildFilter(InvoiceFilter filter)
    {
        var conditions = new List<string>();
        var parameters = new DynamicParameters();
        if (filter.DataInicial is { } start)
        {
            conditions.Add("i.IssuedOn >= @StartDate");
            parameters.Add("StartDate", start.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture));
        }
        if (filter.DataFinal is { } end)
        {
            conditions.Add("i.IssuedOn <= @EndDate");
            parameters.Add("EndDate", end.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture));
        }
        if (filter.ClienteId is { } customerId)
        {
            conditions.Add("i.CustomerId = @CustomerId");
            parameters.Add("CustomerId", customerId);
        }
        if (filter.Situacao is { } status)
        {
            conditions.Add("i.Status = @Status");
            parameters.Add("Status", status);
        }
        return (conditions.Count == 0 ? "" : "WHERE " + string.Join(" AND ", conditions), parameters);
    }

    private static CustomerDto ToCustomer(InvoiceRow row) => new(row.CustomerId, row.CustomerName, row.CustomerCode);
    private static InvoiceDto ToDto(InvoiceRow row) => new(row.Id, row.Number, row.Series,
        DateOnly.FromDateTime(row.IssuedOn), row.Status, ToCustomer(row), row.TotalCents / 100m);

    private static async Task<DbTransaction> BeginReadTransactionAsync(DbConnection connection, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        // A deferred SQLite transaction obtains only a read lock when SELECT runs.
        if (connection is SqliteConnection sqlite) return sqlite.BeginTransaction(deferred: true);
        return await connection.BeginTransactionAsync(IsolationLevel.Serializable, cancellationToken);
    }

    private sealed class InvoiceRow
    {
        public int Id { get; set; }
        public string Number { get; set; } = "";
        public string Series { get; set; } = "";
        public DateTime IssuedOn { get; set; }
        public string Status { get; set; } = "";
        public int CustomerId { get; set; }
        public string CustomerCode { get; set; } = "";
        public string CustomerName { get; set; } = "";
        public long TotalCents { get; set; }
    }

    private sealed class InvoiceItemRow
    {
        public int Id { get; set; }
        public int Sequence { get; set; }
        public int Quantity { get; set; }
        public long UnitPriceCents { get; set; }
        public int ProductId { get; set; }
        public string ProductCode { get; set; } = "";
        public string ProductName { get; set; } = "";
    }

    private sealed class ProductRow
    {
        public int Id { get; set; }
        public string Code { get; set; } = "";
        public string Name { get; set; } = "";
        public long CurrentPriceCents { get; set; }
    }

    private sealed class CustomerRow
    {
        public int Id { get; set; }
        public string Code { get; set; } = "";
        public string Name { get; set; } = "";
    }
}
