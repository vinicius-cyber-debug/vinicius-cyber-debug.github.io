namespace Erp.Infrastructure;

public sealed record DatabaseSettings(string Provider, string ConnectionString, bool SeedDemo);
