using System.Data;
using System.Globalization;
using Dapper;

namespace Erp.Infrastructure;

public sealed class DatabaseInitializer(ConnectionFactory factory)
{
    public async Task InitializeAsync(bool seedDemo, CancellationToken cancellationToken = default)
    {
        await using var connection = await factory.OpenAsync(cancellationToken);
        await using var transaction = await connection.BeginTransactionAsync(IsolationLevel.Serializable, cancellationToken);

        if (factory.Provider == "SqlServer")
        {
            // Serialize schema creation and the emptiness check across application instances.
            var result = await connection.ExecuteScalarAsync<int>(new CommandDefinition("""
                DECLARE @result INT;
                EXEC @result = sys.sp_getapplock
                    @Resource = N'Erp.Demo.Initialization', @LockMode = 'Exclusive',
                    @LockOwner = 'Transaction', @LockTimeout = 15000;
                SELECT @result;
                """, transaction: transaction, cancellationToken: cancellationToken));
            if (result < 0) throw new InvalidOperationException("Não foi possível obter o bloqueio de inicialização do banco.");
        }

        var scriptName = factory.Provider == "SQLite" ? "sqlite.sql" : "sqlserver.sql";
        var assembly = typeof(DatabaseInitializer).Assembly;
        await using var stream = assembly.GetManifestResourceStream($"Erp.Infrastructure.Sql.{scriptName}")
            ?? throw new InvalidOperationException($"Recurso SQL ausente: {scriptName}.");
        using var reader = new StreamReader(stream);
        var script = await reader.ReadToEndAsync(cancellationToken);
        await connection.ExecuteAsync(new CommandDefinition(script, transaction: transaction,
            cancellationToken: cancellationToken));

        if (seedDemo)
        {
            var empty = await connection.ExecuteScalarAsync<int>(new CommandDefinition("""
                SELECT CASE WHEN
                    EXISTS (SELECT 1 FROM Customers) OR EXISTS (SELECT 1 FROM Products) OR
                    EXISTS (SELECT 1 FROM Invoices) OR EXISTS (SELECT 1 FROM InvoiceItems)
                    THEN 0 ELSE 1 END;
                """, transaction: transaction, cancellationToken: cancellationToken));

            if (empty == 1)
            {
                for (var id = 1; id <= 3; id++)
                    await connection.ExecuteAsync(new CommandDefinition(
                        "INSERT INTO Customers (Id, Code, Name) VALUES (@Id, @Code, @Name);",
                        new { Id = id, Code = $"CLI{id:000}", Name = $"Cliente Demonstração {id}" },
                        transaction, cancellationToken: cancellationToken));

                long[] prices = [1250, 3490, 890, 19990, 1599];
                string[] names = ["Caderno demo", "Garrafa demo", "Caneta demo", "Mochila demo", "Estojo demo"];
                for (var id = 1; id <= prices.Length; id++)
                    await connection.ExecuteAsync(new CommandDefinition(
                        "INSERT INTO Products (Id, Code, Name, CurrentPriceCents) VALUES (@Id, @Code, @Name, @Price);",
                        new { Id = id, Code = $"PRO{id:000}", Name = names[id - 1], Price = prices[id - 1] },
                        transaction, cancellationToken: cancellationToken));

                for (var id = 1; id <= 48; id++)
                {
                    var date = new DateOnly(2026, 9, 1).AddDays((id - 1) / 2)
                        .ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
                    var status = (id % 4) switch { 0 => "cancelada", 1 => "pendente", _ => "autorizada" };
                    await connection.ExecuteAsync(new CommandDefinition("""
                        INSERT INTO Invoices (Id, Number, Series, IssuedOn, Status, CustomerId)
                        VALUES (@Id, @Number, 'DEMO', @Date, @Status, @CustomerId);
                        """, new { Id = id, Number = $"SIM-{id:000000}", Date = date,
                        Status = status, CustomerId = ((id - 1) % 3) + 1 }, transaction,
                        cancellationToken: cancellationToken));

                    for (var sequence = 1; sequence <= 2; sequence++)
                    {
                        var productId = sequence == 1 ? ((id - 1) % 5) + 1 : (id % 5) + 1;
                        var quantity = sequence == 1 ? 1 + (id % 3) : 1;
                        await connection.ExecuteAsync(new CommandDefinition("""
                            INSERT INTO InvoiceItems (Id, InvoiceId, Sequence, ProductId, Quantity, UnitPriceCents)
                            VALUES (@Id, @InvoiceId, @Sequence, @ProductId, @Quantity, @Price);
                            """, new { Id = ((id - 1) * 2) + sequence, InvoiceId = id, Sequence = sequence,
                            ProductId = productId, Quantity = quantity, Price = prices[productId - 1] },
                            transaction, cancellationToken: cancellationToken));
                    }
                }
            }
        }

        await transaction.CommitAsync(cancellationToken);
    }
}
