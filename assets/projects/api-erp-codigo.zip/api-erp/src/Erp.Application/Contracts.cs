namespace Erp.Application;

public sealed record CustomerDto(int Id, string Nome, string Codigo);
public sealed record ProductDto(int Id, string Codigo, string Nome, decimal ValorAtual);
public sealed record ItemProductDto(int Id, string Codigo, string Nome);
public sealed record InvoiceDto(int Id, string Numero, string Serie, DateOnly Emissao,
    string Situacao, CustomerDto Cliente, decimal Total);
public sealed record InvoiceItemDto(int Id, int Sequencia, ItemProductDto Produto,
    int Quantidade, decimal ValorUnitario, decimal ValorTotal);
public sealed record InvoiceDetailDto(int Id, string Numero, string Serie, DateOnly Emissao,
    string Situacao, CustomerDto Cliente, decimal Total, IReadOnlyList<InvoiceItemDto> Itens);
public sealed record PageDto<T>(IReadOnlyList<T> Items, int Page, int PageSize, long TotalCount)
{
    public long TotalPages => (TotalCount + PageSize - 1) / PageSize;
}

public interface IInvoiceRepository
{
    Task<PageDto<InvoiceDto>> ListAsync(InvoiceFilter filter, CancellationToken cancellationToken);
    Task<InvoiceDetailDto?> GetAsync(int id, CancellationToken cancellationToken);
    Task<IReadOnlyList<CustomerDto>> CustomersAsync(CancellationToken cancellationToken);
    Task<IReadOnlyList<ProductDto>> ProductsAsync(CancellationToken cancellationToken);
    Task<bool> IsAvailableAsync(CancellationToken cancellationToken);
}
