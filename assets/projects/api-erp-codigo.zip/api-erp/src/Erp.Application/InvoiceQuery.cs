using System.Globalization;

namespace Erp.Application;

public sealed record InvoiceFilter(DateOnly? DataInicial, DateOnly? DataFinal,
    int? ClienteId, string? Situacao, int Page, int PageSize)
{
    public long Offset => ((long)Page - 1) * PageSize;
}

public sealed class QueryValidationException(Dictionary<string, string[]> errors) : Exception("Parâmetros inválidos.")
{
    public Dictionary<string, string[]> Errors { get; } = errors;
}

public static class InvoiceQuery
{
    public static InvoiceFilter Parse(string? dataInicial = null, string? dataFinal = null,
        string? clienteId = null, string? situacao = null, string? page = null, string? pageSize = null)
    {
        var errors = new Dictionary<string, string[]>();
        DateOnly? Date(string? raw, string key)
        {
            if (raw is null) return null;
            if (DateOnly.TryParseExact(raw, "yyyy-MM-dd", CultureInfo.InvariantCulture,
                DateTimeStyles.None, out var value)) return value;
            errors[key] = ["Informe uma data válida no formato YYYY-MM-DD."];
            return null;
        }
        int? PositiveInt(string? raw, string key, int? defaultValue = null, int maximum = int.MaxValue)
        {
            if (raw is null) return defaultValue;
            if (int.TryParse(raw, NumberStyles.None, CultureInfo.InvariantCulture, out var value)
                && value >= 1 && value <= maximum) return value;
            errors[key] = [maximum == int.MaxValue
                ? "Informe um número inteiro positivo."
                : $"Informe um número inteiro entre 1 e {maximum}."];
            return null;
        }

        var start = Date(dataInicial, "dataInicial");
        var end = Date(dataFinal, "dataFinal");
        var customer = PositiveInt(clienteId, "clienteId");
        var currentPage = PositiveInt(page, "page", 1);
        var size = PositiveInt(pageSize, "pageSize", 20, 100);
        var status = situacao?.ToLowerInvariant();
        if (status is not null && status is not ("autorizada" or "cancelada" or "pendente"))
            errors["situacao"] = ["Use autorizada, cancelada ou pendente."];
        if (start is not null && end is not null && start > end)
            errors["dataFinal"] = ["A data final deve ser igual ou posterior à data inicial."];
        if (errors.Count > 0) throw new QueryValidationException(errors);

        return new InvoiceFilter(start, end, customer, status, currentPage!.Value, size!.Value);
    }

    public static int ParseId(string id)
    {
        if (int.TryParse(id, NumberStyles.None, CultureInfo.InvariantCulture, out var value) && value > 0)
            return value;
        throw new QueryValidationException(new() { ["id"] = ["Informe um número inteiro positivo."] });
    }
}
