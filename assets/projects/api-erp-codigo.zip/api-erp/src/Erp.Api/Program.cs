using System.Diagnostics;
using System.Reflection;
using Erp.Api;
using Erp.Application;
using Erp.Infrastructure;
using Microsoft.Data.SqlClient;
using Microsoft.Data.Sqlite;
using Microsoft.OpenApi;

var builder = WebApplication.CreateBuilder(args);
builder.Logging.AddJsonConsole();
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "API ERP — Vinicius Maia",
        Version = "v1",
        Description = "MVP de consultas com dados sintéticos. ERP simulado; não há integração real com Protheus. " +
            "A base de demonstração contém 48 notas entre 2026-09-01 e 2026-09-24. " +
            "Comece por GET /api/notas-fiscais com pageSize=5 e depois consulte /api/notas-fiscais/48."
    });
    options.IncludeXmlComments(Path.Combine(AppContext.BaseDirectory,
        $"{Assembly.GetExecutingAssembly().GetName().Name}.xml"));
});

// Resolve paths from the API project, not from the terminal's current folder.
builder.Services.AddSingleton(serviceProvider =>
{
    var config = serviceProvider.GetRequiredService<IConfiguration>();
    var provider = (config["Database:Provider"] ?? "Sqlite").Trim();
    var connectionString = config["Database:ConnectionString"]
        ?? throw new InvalidOperationException("Configure Database:ConnectionString.");
    if (provider.Equals("Sqlite", StringComparison.OrdinalIgnoreCase))
    {
        var sqlite = new SqliteConnectionStringBuilder(connectionString) { ForeignKeys = true };
        if (sqlite.DataSource != ":memory:" && !string.IsNullOrWhiteSpace(sqlite.DataSource))
        {
            sqlite.DataSource = Path.GetFullPath(sqlite.DataSource, builder.Environment.ContentRootPath);
            Directory.CreateDirectory(Path.GetDirectoryName(sqlite.DataSource)!);
        }
        connectionString = sqlite.ToString();
    }
    else if (provider.Equals("SqlServer", StringComparison.OrdinalIgnoreCase))
    {
        // The builder quotes special characters instead of interpolating a
        // password into connection-string syntax.
        var sqlServer = new SqlConnectionStringBuilder(connectionString);
        var password = config["Database:Password"];
        if (password is not null) sqlServer.Password = password;
        connectionString = sqlServer.ConnectionString;
    }
    return new DatabaseSettings(provider, connectionString, config.GetValue("Database:SeedDemo", true));
});
builder.Services.AddSingleton<ConnectionFactory>();
builder.Services.AddSingleton<DatabaseInitializer>();
builder.Services.AddScoped<IInvoiceRepository, InvoiceRepository>();

var app = builder.Build();
await app.Services.GetRequiredService<DatabaseInitializer>().InitializeAsync(
    app.Services.GetRequiredService<DatabaseSettings>().SeedDemo);

app.Use(async (context, next) =>
{
    var started = Stopwatch.GetTimestamp();
    try { await next(context); }
    finally
    {
        app.Logger.LogInformation("{Method} {Path} -> {StatusCode} in {ElapsedMs}ms, trace {TraceId}",
            context.Request.Method, context.Request.Path, context.Response.StatusCode,
            Stopwatch.GetElapsedTime(started).TotalMilliseconds, context.TraceIdentifier);
    }
});
app.UseMiddleware<ApiErrorMiddleware>();
app.UseSwagger();
app.UseSwaggerUI(options =>
{
    options.SwaggerEndpoint("/swagger/v1/swagger.json", "API ERP v1 — dados fictícios");
    options.DocumentTitle = "API ERP | Vinicius Maia";
    options.DefaultModelsExpandDepth(-1);
});
app.MapControllers();
app.MapGet("/", () => Results.Redirect("/swagger")).ExcludeFromDescription();
app.MapGet("/health", async (IInvoiceRepository repository, CancellationToken token) =>
{
    try
    {
        return await repository.IsAvailableAsync(token)
            ? Results.Ok(new { status = "healthy" })
            : Results.Json(new { status = "unavailable" }, statusCode: 503);
    }
    catch (Exception exception) when (exception is not OperationCanceledException)
    {
        app.Logger.LogError(exception, "Falha na verificação do banco de dados.");
        return Results.Json(new { status = "unavailable" }, statusCode: 503);
    }
}).WithName("Health").WithTags("Disponibilidade")
    .WithSummary("Verifica a conexão com o banco de dados.");
await app.RunAsync();

public partial class Program;
