using Erp.Application;
using Microsoft.AspNetCore.Mvc;

namespace Erp.Api.Controllers;

[ApiController]
[Tags("Catálogos")]
public sealed class CatalogController(IInvoiceRepository repository) : ControllerBase
{
    /// <summary>Lista os clientes fictícios para selecionar o filtro clienteId.</summary>
    [HttpGet("api/clientes")]
    [ProducesResponseType<IReadOnlyList<CustomerDto>>(200, "application/json")]
    [ProducesResponseType<ProblemDetails>(500, "application/problem+json")]
    public async Task<ActionResult<IReadOnlyList<CustomerDto>>> Customers(CancellationToken cancellationToken)
        => Ok(await repository.CustomersAsync(cancellationToken));

    /// <summary>Lista os produtos fictícios e seus preços atuais.</summary>
    /// <remarks>O detalhe da nota preserva o preço do item; esse catálogo não recalcula notas antigas.</remarks>
    [HttpGet("api/produtos")]
    [ProducesResponseType<IReadOnlyList<ProductDto>>(200, "application/json")]
    [ProducesResponseType<ProblemDetails>(500, "application/problem+json")]
    public async Task<ActionResult<IReadOnlyList<ProductDto>>> Products(CancellationToken cancellationToken)
        => Ok(await repository.ProductsAsync(cancellationToken));
}
