using Erp.Application;
using Microsoft.AspNetCore.Mvc;

namespace Erp.Api.Controllers;

[ApiController]
[Route("api/notas-fiscais")]
[Tags("Notas fiscais")]
public sealed class InvoicesController(IInvoiceRepository repository) : ControllerBase
{
    /// <summary>Consulta notas fiscais com filtros combinados e paginação.</summary>
    /// <remarks>
    /// Datas inclusivas. Ordenação fixa: emissão decrescente e ID decrescente.
    /// Consulta sem resultados ou página além do fim retorna 200 com items vazio.
    /// Exemplo: /api/notas-fiscais?dataInicial=2026-09-01&amp;dataFinal=2026-09-24&amp;clienteId=1&amp;situacao=autorizada&amp;page=1&amp;pageSize=5
    /// </remarks>
    /// <param name="dataInicial">Início opcional (YYYY-MM-DD). Exemplo: 2026-09-01.</param>
    /// <param name="dataFinal">Fim opcional (YYYY-MM-DD), inclusive. Exemplo: 2026-09-24.</param>
    /// <param name="clienteId">ID positivo; consulte /api/clientes. Cliente inexistente retorna lista vazia.</param>
    /// <param name="situacao">autorizada, cancelada ou pendente (ignora maiúsculas).</param>
    /// <param name="page">Página a partir de 1. Padrão: 1.</param>
    /// <param name="pageSize">Entre 1 e 100. Padrão: 20.</param>
    /// <param name="cancellationToken">Cancelamento da requisição.</param>
    [HttpGet]
    [ProducesResponseType<PageDto<InvoiceDto>>(200, "application/json")]
    [ProducesResponseType<ValidationProblemDetails>(400, "application/problem+json")]
    [ProducesResponseType<ProblemDetails>(500, "application/problem+json")]
    public async Task<ActionResult<PageDto<InvoiceDto>>> List(
        [FromQuery] string? dataInicial, [FromQuery] string? dataFinal,
        [FromQuery] string? clienteId, [FromQuery] string? situacao,
        [FromQuery] string? page, [FromQuery] string? pageSize, CancellationToken cancellationToken)
    {
        // MVC normalizes empty strings to null. Preserve a supplied empty value
        // so invalid inputs receive 400 instead of silently using defaults.
        string? Raw(string name) => Request.Query.TryGetValue(name, out var value) ? value.ToString() : null;
        var filter = InvoiceQuery.Parse(Raw(nameof(dataInicial)), Raw(nameof(dataFinal)),
            Raw(nameof(clienteId)), Raw(nameof(situacao)), Raw(nameof(page)), Raw(nameof(pageSize)));
        return Ok(await repository.ListAsync(filter, cancellationToken));
    }

    /// <summary>Retorna uma nota fiscal com cliente, produtos e todos os itens.</summary>
    /// <remarks>Valores em reais. O preço do item é o valor histórico da nota. Exemplo: ID 48.</remarks>
    /// <param name="id">ID interno positivo da nota; não é o número fiscal.</param>
    /// <param name="cancellationToken">Cancelamento da requisição.</param>
    [HttpGet("{id}")]
    [ProducesResponseType<InvoiceDetailDto>(200, "application/json")]
    [ProducesResponseType<ValidationProblemDetails>(400, "application/problem+json")]
    [ProducesResponseType<ProblemDetails>(404, "application/problem+json")]
    [ProducesResponseType<ProblemDetails>(500, "application/problem+json")]
    public async Task<ActionResult<InvoiceDetailDto>> Get([FromRoute] string id,
        CancellationToken cancellationToken)
    {
        var invoice = await repository.GetAsync(InvoiceQuery.ParseId(id), cancellationToken);
        if (invoice is null)
        {
            var problem = new ProblemDetails
            {
                Status = 404, Title = "Nota fiscal não encontrada.",
                Detail = "Nenhuma nota fiscal corresponde ao ID informado.",
                Instance = Request.Path,
                Type = "https://www.rfc-editor.org/rfc/rfc9110#section-15.5.5"
            };
            problem.Extensions["traceId"] = HttpContext.TraceIdentifier;
            return new JsonResult(problem) { StatusCode = 404, ContentType = "application/problem+json" };
        }
        return Ok(invoice);
    }
}
