using System.Text.Json;
using Erp.Application;
using Microsoft.AspNetCore.Mvc;

namespace Erp.Api;

public sealed class ApiErrorMiddleware(RequestDelegate next, ILogger<ApiErrorMiddleware> logger)
{
    public async Task InvokeAsync(HttpContext context)
    {
        try { await next(context); }
        catch (OperationCanceledException) when (context.RequestAborted.IsCancellationRequested)
        {
            // The caller disconnected; do not turn cancellation into a server failure.
            context.Response.StatusCode = 499;
        }
        catch (Exception exception)
        {
            if (context.Response.HasStarted) throw;
            ProblemDetails problem;
            if (exception is QueryValidationException validation)
            {
                problem = new ValidationProblemDetails(validation.Errors)
                {
                    Status = 400,
                    Title = "Parâmetros inválidos.",
                    Detail = "Corrija os campos indicados e tente novamente.",
                    Type = "https://www.rfc-editor.org/rfc/rfc9110#section-15.5.1"
                };
                logger.LogWarning("Consulta rejeitada, campos {Fields}, trace {TraceId}",
                    string.Join(", ", validation.Errors.Keys), context.TraceIdentifier);
            }
            else
            {
                logger.LogError(exception, "Erro ao processar {Path}, trace {TraceId}",
                    context.Request.Path, context.TraceIdentifier);
                problem = new ProblemDetails
                {
                    Status = 500,
                    Title = "Não foi possível concluir a consulta.",
                    Detail = "Ocorreu um erro interno. Tente novamente e informe o traceId se o erro persistir.",
                    Type = "https://www.rfc-editor.org/rfc/rfc9110#section-15.6.1"
                };
            }
            problem.Instance = context.Request.Path;
            problem.Extensions["traceId"] = context.TraceIdentifier;
            context.Response.Clear();
            context.Response.StatusCode = problem.Status!.Value;
            await context.Response.WriteAsJsonAsync(problem, problem.GetType(),
                options: (JsonSerializerOptions?)null, contentType: "application/problem+json",
                cancellationToken: context.RequestAborted);
        }
    }
}
