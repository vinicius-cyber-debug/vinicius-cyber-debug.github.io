# API de Integração ERP — Vinicius Maia

MVP de leitura de notas fiscais com dados sintéticos. Demonstra filtros, paginação, relacionamentos, validação, acesso a dados com Dapper e documentação interativa. **O ERP é simulado; não há integração com Protheus ou outro ERP real.**

Este é o primeiro projeto do plano. Os outros cinco projetos continuam planejados. A seção de projetos do portfólio não foi alterada.

## Executar a demonstração

Requisito: **SDK .NET 10**, que inclui o runtime ASP.NET Core. Apenas o runtime do .NET não permite compilar o projeto. A primeira execução precisa de internet para restaurar os pacotes NuGet; depois disso a demonstração não depende de serviços externos.

Na pasta deste README:

```powershell
dotnet restore Erp.slnx --locked-mode
dotnet run --project src/Erp.Api/Erp.Api.csproj --launch-profile demo
```

Abra [Swagger](http://127.0.0.1:5080/swagger). A API cria `src/Erp.Api/data/erp-demo.db` e preenche a base vazia automaticamente. Não precisa instalar um banco para essa demonstração.

No Windows, `powershell -ExecutionPolicy Bypass -File .\Iniciar-demo.ps1` também inicia a API. O script procura o SDK instalado; nesta sessão ele também encontra o SDK local preparado na pasta de trabalho pelo Codex. Em outra máquina, instale o SDK ou informe `-DotnetPath C:\caminho\dotnet.exe`. A instalação local não foi adicionada ao PATH do computador.

Para encerrar, use Ctrl+C no terminal. Para recriar a base de demonstração, encerre a API e renomeie o arquivo `erp-demo.db`, preservando-o como cópia. Não use esse procedimento em uma base real.

## Fluxo demonstrável

1. Consulte `/api/clientes` para conhecer os IDs fictícios.
2. Execute `/api/notas-fiscais?dataInicial=2026-09-01&dataFinal=2026-09-24&clienteId=1&situacao=autorizada&page=1&pageSize=5`.
3. Consulte `/api/notas-fiscais/48` para ver cliente, produtos, dois itens e total calculado.
4. Envie `pageSize=101` ou um período invertido e observe o erro 400 com os campos a corrigir.
5. Consulte `/api/notas-fiscais/999` e observe o erro 404.

O arquivo `demo.http` contém essas requisições, que podem ser executadas em um editor com suporte a arquivos HTTP ou pelo Swagger. Veja o [relatório com evidências reais de execução](docs/evidencias/validacao.md).

## Contrato HTTP

| Método e rota | Comportamento |
| --- | --- |
| `GET /api/notas-fiscais` | Lista paginada, com filtros opcionais combinados por AND |
| `GET /api/notas-fiscais/{id}` | Detalhe completo de uma nota |
| `GET /api/clientes` | Clientes fictícios disponíveis para o filtro |
| `GET /api/produtos` | Catálogo de produtos e preços atuais |
| `GET /health` | `200` e `status: healthy` quando o banco responde; `503` quando indisponível |
| `GET /swagger` | Documentação interativa |
| `GET /swagger/v1/swagger.json` | Contrato OpenAPI gerado pela API |

| Parâmetro | Regra |
| --- | --- |
| `dataInicial`, `dataFinal` | Datas opcionais em `YYYY-MM-DD`, ambas inclusivas; limite ausente deixa esse lado aberto |
| `clienteId` | Inteiro positivo; cliente inexistente retorna coleção vazia |
| `situacao` | `autorizada`, `cancelada` ou `pendente`; aceita maiúsculas e minúsculas |
| `page` | Inteiro positivo, padrão 1 |
| `pageSize` | Inteiro de 1 a 100, padrão 20 |

Ordenação: emissão decrescente, depois ID decrescente. A resposta contém `items`, `page`, `pageSize`, `totalCount` e `totalPages`. Uma página além do fim retorna `200` com `items: []`. Uma consulta sem resultados tem `totalCount: 0` e `totalPages: 0`. Strings vazias e valores inválidos produzem erro 400.

Erros de entrada usam `application/problem+json`, com `title`, `status`, `detail`, `instance`, `errors` e `traceId`. Um ID válido ausente produz 404. Falhas inesperadas produzem 500 com mensagem genérica; os detalhes técnicos ficam nos logs, vinculados ao `traceId`.

## Modelo e decisões

```mermaid
erDiagram
    Customers ||--o{ Invoices : possui
    Invoices ||--|{ InvoiceItems : contem
    Products ||--o{ InvoiceItems : identifica
```

- Um cliente pode ter várias notas. Cada nota tem vários itens, e cada item referencia um produto. Chaves estrangeiras, quantidades positivas e valores não negativos são protegidos no banco.
- O ID interno identifica a nota. Número e série formam uma chave única no cenário de um único emissor simulado. Um ERP com vários emissores exigiria ampliar essa chave.
- Dinheiro é armazenado em centavos inteiros e exposto como `decimal` em reais. As quantidades deste MVP são unidades inteiras; não há fracionamento nem cálculos de tributos.
- O preço de cada item é uma cópia histórica. Alterar o preço atual do produto não altera os valores de notas anteriores. Notas canceladas preservam os itens e os valores registrados.
- Emissão é uma data sem horário. SQLite armazena texto ISO; SQL Server usa `DATE`. A API expõe `DateOnly`.
- SQL é parametrizado. A paginação ocorre sobre notas, antes de carregar os itens do detalhe. A contagem aplica exatamente os mesmos filtros.
- A base fictícia contém 3 clientes, 5 produtos, 48 notas, 96 itens e duas notas por dia de 1 a 24 de setembro de 2026. O seed é transacional e não substitui dados existentes.

## Arquitetura

```text
Erp.Api             HTTP, Swagger, configuração, erros e logs
    ↓
Erp.Application     DTOs, regras de validação e contrato IInvoiceRepository
    ↑
Erp.Infrastructure  Dapper, conexões, SQL, consultas e seed
```

A camada Application não depende de ASP.NET Core nem de um provedor SQL. A API recebe uma implementação de `IInvoiceRepository` por injeção de dependência. Este MVP de leitura não precisa de uma camada de serviços que apenas repasse chamadas; regras de entrada ficam no parser da Application. Um futuro adaptador para ERP real pode implementar o mesmo contrato.

Os logs incluem rota, status, duração e `traceId`. A duração registrada é uma medida por requisição, não um benchmark. Não foram feitas afirmações de redução de custos, ganho de produtividade ou desempenho em produção.

## SQL Server

O código inclui um adaptador SQL Server com Microsoft.Data.SqlClient, schema próprio e paginação `OFFSET/FETCH`. **A execução validada nesta entrega usa SQLite. SQL Server e Docker não estão instalados neste computador; o caminho SQL Server precisa de validação em um laboratório antes de ser apresentado como testado.**

Com Docker e Compose disponíveis, copie `.env.example` para `.env`, preencha `MSSQL_SA_PASSWORD` com uma senha forte para seu laboratório e execute:

```powershell
docker compose up --build
```

O Compose inicia SQL Server 2022 Developer, aguarda a verificação de disponibilidade, cria o banco `ErpDemo` e inicia a API na mesma URL local. A API aplica o schema e o seed. O volume `sql-data` preserva os dados. `docker compose down` encerra os serviços e preserva o volume.

A senha chega por `Database__Password` e é inserida com `SqlConnectionStringBuilder`, para preservar caracteres especiais. No arquivo `.env`, use aspas simples no valor para impedir a interpolação de `$` pelo Compose.

Para usar uma instância existente, crie um banco vazio dedicado ao laboratório e configure por variáveis de ambiente:

```powershell
$env:Database__Provider = 'SqlServer'
$env:Database__ConnectionString = 'Server=localhost;Database=ErpDemo;Integrated Security=True;Encrypt=True;TrustServerCertificate=True'
$env:Database__SeedDemo = 'true'
dotnet run --project src/Erp.Api/Erp.Api.csproj --launch-profile demo
```

Essas configurações são exemplos locais. O usuário de inicialização precisa criar tabelas e inserir os dados. O Compose usa `sa` e certificado confiado apenas para simplificar o laboratório. Antes de uma implantação real, separe o usuário de migração do usuário de leitura, use certificados válidos e autentique o acesso à API. Mantenha `.env` fora do controle de versão.

## Verificação

```powershell
dotnet restore Erp.slnx --locked-mode
dotnet test Erp.slnx -c Release --no-restore
```

No Windows, `powershell -ExecutionPolicy Bypass -File .\Verificar.ps1` resolve o SDK da mesma forma que o script da demonstração. Os arquivos `packages.lock.json` fixam também as dependências transitivas.

Os testes verificam validações, filtros, datas inclusivas, contagem, ordenação e paginação, nota com relacionamentos e valores corretos, preservação de preços históricos, seed idempotente, erros 400/404/500, disponibilidade e geração do contrato Swagger. O relatório de validação na pasta de evidências registra o que efetivamente foi executado.

## Limitações e próximos passos

O MVP é somente leitura, sem autenticação, emissão fiscal, integração com ERP, chave de acesso fiscal, impostos, descontos ou edição concorrente de notas. Os nomes, códigos e números são fictícios. Catálogos são pequenos e não paginados nesta base de demonstração. O esquema não substitui uma modelagem fiscal completa.

Para evoluir: validar o caminho SQL Server em laboratório, adicionar autenticação, criar um adaptador real com autorização de acesso ao ERP, tratar migrações versionadas e testar comportamento com dados maiores e alterações concorrentes. Só depois medir resultados e atualizar a apresentação do portfólio, distinguindo o que está implementado do que continua planejado.

Referências de execução: [instalação oficial do .NET](https://learn.microsoft.com/dotnet/core/install/windows), [Dapper](https://github.com/DapperLib/Dapper), [Swagger/Swashbuckle](https://github.com/domaindrivendev/Swashbuckle.AspNetCore), [SQL Server em Docker](https://learn.microsoft.com/sql/linux/quickstart-install-connect-docker).
