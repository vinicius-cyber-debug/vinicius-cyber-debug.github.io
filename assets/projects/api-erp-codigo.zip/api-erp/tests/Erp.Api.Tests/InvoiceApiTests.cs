using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Erp.Application;

namespace Erp.Api.Tests;

public sealed class InvoiceApiTests(DemoApiFactory factory) : IClassFixture<DemoApiFactory>
{
    [Fact]
    public async Task Default_page_has_metadata_and_stable_newest_first_order()
    {
        using var client = factory.CreateClient();
        var page = await GetPageAsync(client);

        Assert.Equal(1, page.Page);
        Assert.Equal(20, page.PageSize);
        Assert.Equal(48L, page.TotalCount);
        Assert.Equal(3L, page.TotalPages);
        Assert.Equal(Enumerable.Range(29, 20).Reverse(), page.Items.Select(invoice => invoice.Id));
        Assert.Equal(new DateOnly(2026, 9, 24), page.Items[0].Emissao);
        Assert.Equal(208.80m, page.Items[0].Total);
    }

    [Fact]
    public async Task Date_boundaries_are_inclusive()
    {
        using var client = factory.CreateClient();
        var page = await GetPageAsync(client, "?dataInicial=2026-09-05&dataFinal=2026-09-07");

        Assert.Equal(6L, page.TotalCount);
        Assert.Equal(new[] { 14, 13, 12, 11, 10, 9 }, page.Items.Select(invoice => invoice.Id));
        Assert.Contains(page.Items, invoice => invoice.Emissao == new DateOnly(2026, 9, 5));
        Assert.Contains(page.Items, invoice => invoice.Emissao == new DateOnly(2026, 9, 7));
    }

    [Fact]
    public async Task Same_day_interval_includes_both_invoices()
    {
        using var client = factory.CreateClient();
        var page = await GetPageAsync(client, "?dataInicial=2026-09-05&dataFinal=2026-09-05");

        Assert.Equal(2L, page.TotalCount);
        Assert.Equal(new[] { 10, 9 }, page.Items.Select(invoice => invoice.Id));
    }

    [Theory]
    [InlineData("?dataInicial=2026-09-23", 48, 47, 46, 45)]
    [InlineData("?dataFinal=2026-09-02", 4, 3, 2, 1)]
    public async Task Date_interval_supports_one_open_boundary(string query, int a, int b, int c, int d)
    {
        using var client = factory.CreateClient();
        var page = await GetPageAsync(client, query);

        Assert.Equal(4L, page.TotalCount);
        Assert.Equal(new[] { a, b, c, d }, page.Items.Select(invoice => invoice.Id));
    }

    [Fact]
    public async Task Customer_filter_returns_only_that_customer()
    {
        using var client = factory.CreateClient();
        var page = await GetPageAsync(client, "?clienteId=2&pageSize=100");

        Assert.Equal(16L, page.TotalCount);
        Assert.Equal(Enumerable.Range(0, 16).Select(index => 47 - index * 3), page.Items.Select(invoice => invoice.Id));
        Assert.All(page.Items, invoice => Assert.Equal(2, invoice.Cliente.Id));
    }

    [Theory]
    [InlineData("autorizada", 24)]
    [InlineData("cancelada", 12)]
    [InlineData("pendente", 12)]
    public async Task Status_filter_returns_only_that_status(string status, long count)
    {
        using var client = factory.CreateClient();
        var page = await GetPageAsync(client, $"?situacao={status}&pageSize=100");

        Assert.Equal(count, page.TotalCount);
        Assert.Equal(count, (long)page.Items.Count);
        Assert.All(page.Items, invoice => Assert.Equal(status, invoice.Situacao));
    }

    [Fact]
    public async Task All_filters_are_combined_and_total_count_uses_the_same_filters()
    {
        using var client = factory.CreateClient();
        var page = await GetPageAsync(client,
            "?dataInicial=2026-09-03&dataFinal=2026-09-12&clienteId=2&situacao=AUTORIZADA&pageSize=2");
        var next = await GetPageAsync(client,
            "?dataInicial=2026-09-03&dataFinal=2026-09-12&clienteId=2&situacao=AUTORIZADA&pageSize=2&page=2");

        Assert.Equal(3L, page.TotalCount);
        Assert.Equal(2L, page.TotalPages);
        Assert.Equal(new[] { 23, 14 }, page.Items.Select(invoice => invoice.Id));
        Assert.Equal(3L, next.TotalCount);
        Assert.Equal(new[] { 11 }, next.Items.Select(invoice => invoice.Id));
    }

    [Fact]
    public async Task Paging_has_no_duplicate_or_missing_invoice_even_with_date_ties()
    {
        using var client = factory.CreateClient();
        var ids = new List<int>();
        for (var number = 1; number <= 7; number++)
        {
            var page = await GetPageAsync(client, $"?page={number}&pageSize=7");
            Assert.Equal(number, page.Page);
            Assert.Equal(7, page.PageSize);
            Assert.Equal(48L, page.TotalCount);
            Assert.Equal(7L, page.TotalPages);
            ids.AddRange(page.Items.Select(invoice => invoice.Id));
        }

        Assert.Equal(Enumerable.Range(1, 48).Reverse(), ids);
        Assert.Equal(48, ids.Distinct().Count());
    }

    [Theory]
    [InlineData("?clienteId=999999", 0)]
    [InlineData("?dataInicial=2027-01-01", 0)]
    [InlineData("?page=4", 48)]
    [InlineData("?page=2147483647&pageSize=100", 48)]
    public async Task Empty_queries_and_pages_beyond_the_end_are_successful(string query, long count)
    {
        using var client = factory.CreateClient();
        var page = await GetPageAsync(client, query);

        Assert.Empty(page.Items);
        Assert.Equal(count, page.TotalCount);
        Assert.Equal(count == 0 ? 0L : (count + page.PageSize - 1) / page.PageSize, page.TotalPages);
    }

    [Fact]
    public async Task Detail_contains_the_correct_customer_products_and_snapshot_values()
    {
        using var client = factory.CreateClient();
        using var response = await client.GetAsync("/api/notas-fiscais/1");
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var detail = await response.Content.ReadFromJsonAsync<InvoiceDetailDto>();
        Assert.NotNull(detail);

        Assert.Equal(1, detail.Id);
        Assert.Equal(new DateOnly(2026, 9, 1), detail.Emissao);
        Assert.Equal("pendente", detail.Situacao);
        Assert.Equal(1, detail.Cliente.Id);
        Assert.False(string.IsNullOrWhiteSpace(detail.Cliente.Nome));
        Assert.Equal(59.90m, detail.Total);
        Assert.Collection(detail.Itens,
            first =>
            {
                Assert.Equal(1, first.Sequencia);
                Assert.Equal(1, first.Produto.Id);
                Assert.False(string.IsNullOrWhiteSpace(first.Produto.Codigo));
                Assert.False(string.IsNullOrWhiteSpace(first.Produto.Nome));
                Assert.Equal(2, first.Quantidade);
                Assert.Equal(12.50m, first.ValorUnitario);
                Assert.Equal(25m, first.ValorTotal);
            },
            second =>
            {
                Assert.Equal(2, second.Sequencia);
                Assert.Equal(2, second.Produto.Id);
                Assert.Equal(1, second.Quantidade);
                Assert.Equal(34.90m, second.ValorUnitario);
                Assert.Equal(34.90m, second.ValorTotal);
            });
        Assert.Equal(detail.Total, detail.Itens.Sum(item => item.ValorTotal));
    }

    [Fact]
    public async Task Cancelled_invoice_keeps_its_original_items_and_total()
    {
        using var client = factory.CreateClient();
        var detail = await client.GetFromJsonAsync<InvoiceDetailDto>("/api/notas-fiscais/48");
        Assert.NotNull(detail);

        Assert.Equal("cancelada", detail.Situacao);
        Assert.Equal(3, detail.Cliente.Id);
        Assert.Equal(new[] { 3, 4 }, detail.Itens.Select(item => item.Produto.Id));
        Assert.Equal(208.80m, detail.Total);
        Assert.Equal(detail.Total, detail.Itens.Sum(item => item.ValorTotal));
    }

    [Fact]
    public async Task Missing_detail_returns_a_404_problem()
    {
        using var client = factory.CreateClient();
        using var response = await client.GetAsync("/api/notas-fiscais/999999");
        using var problem = await AssertProblemAsync(response, HttpStatusCode.NotFound);
    }

    [Theory]
    [InlineData("?dataInicial=2026-02-30", "dataInicial")]
    [InlineData("?dataFinal=05%2F09%2F2026", "dataFinal")]
    [InlineData("?dataInicial=2026-09-06&dataFinal=2026-09-05", "dataFinal")]
    [InlineData("?clienteId=0", "clienteId")]
    [InlineData("?clienteId=2147483648", "clienteId")]
    [InlineData("?situacao=inexistente", "situacao")]
    [InlineData("?situacao=autorizada%27%20OR%201%3D1--", "situacao")]
    [InlineData("?page=0", "page")]
    [InlineData("?page=abc", "page")]
    [InlineData("?pageSize=101", "pageSize")]
    [InlineData("?pageSize=0", "pageSize")]
    [InlineData("?pageSize=", "pageSize")]
    [InlineData("?clienteId=", "clienteId")]
    [InlineData("?situacao=", "situacao")]
    [InlineData("?dataInicial=", "dataInicial")]
    public async Task Invalid_query_returns_a_400_problem_with_field_errors(string query, string field)
    {
        using var client = factory.CreateClient();
        using var response = await client.GetAsync("/api/notas-fiscais" + query);
        using var problem = await AssertProblemAsync(response, HttpStatusCode.BadRequest);

        var errors = problem.RootElement.GetProperty("errors");
        Assert.True(errors.TryGetProperty(field, out var messages));
        Assert.Equal(JsonValueKind.Array, messages.ValueKind);
        Assert.NotEmpty(messages.EnumerateArray());
        Assert.All(messages.EnumerateArray(), message => Assert.False(string.IsNullOrWhiteSpace(message.GetString())));
    }

    [Theory]
    [InlineData("0")]
    [InlineData("-1")]
    [InlineData("abc")]
    [InlineData("2147483648")]
    public async Task Invalid_detail_id_returns_a_field_error(string id)
    {
        using var client = factory.CreateClient();
        using var response = await client.GetAsync("/api/notas-fiscais/" + id);
        using var problem = await AssertProblemAsync(response, HttpStatusCode.BadRequest);

        Assert.True(problem.RootElement.GetProperty("errors").TryGetProperty("id", out _));
    }

    [Fact]
    public async Task Auxiliary_endpoints_expose_synthetic_customers_and_products()
    {
        using var client = factory.CreateClient();
        var customers = await client.GetFromJsonAsync<List<CustomerDto>>("/api/clientes");
        var products = await client.GetFromJsonAsync<List<ProductDto>>("/api/produtos");
        Assert.NotNull(customers);
        Assert.NotNull(products);

        Assert.Equal(new[] { 1, 2, 3 }, customers.Select(customer => customer.Id).Order());
        Assert.Equal(new[] { 1, 2, 3, 4, 5 }, products.Select(product => product.Id).Order());
        Assert.All(customers, customer => Assert.False(string.IsNullOrWhiteSpace(customer.Nome)));
        Assert.All(products, product => Assert.True(product.ValorAtual > 0));
    }

    [Fact]
    public async Task Health_is_successful_when_the_database_is_available()
    {
        using var client = factory.CreateClient();
        using var response = await client.GetAsync("/health");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        using var health = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
        Assert.Equal("healthy", health.RootElement.GetProperty("status").GetString());
    }

    [Fact]
    public async Task Swagger_ui_and_document_are_available_with_query_and_detail_paths()
    {
        using var client = factory.CreateClient();
        using var ui = await client.GetAsync("/swagger");
        Assert.Equal(HttpStatusCode.OK, ui.StatusCode);
        Assert.Contains("swagger", await ui.Content.ReadAsStringAsync(), StringComparison.OrdinalIgnoreCase);

        using var response = await client.GetAsync("/swagger/v1/swagger.json");
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        using var document = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
        var paths = document.RootElement.GetProperty("paths");
        Assert.True(paths.GetProperty("/api/notas-fiscais").TryGetProperty("get", out var list));
        Assert.True(paths.GetProperty("/api/notas-fiscais/{id}").TryGetProperty("get", out var detail));
        Assert.True(list.GetProperty("responses").GetProperty("400").GetProperty("content")
            .TryGetProperty("application/problem+json", out _));
        Assert.True(list.GetProperty("responses").GetProperty("500").GetProperty("content")
            .TryGetProperty("application/problem+json", out _));
        Assert.True(detail.GetProperty("responses").GetProperty("404").GetProperty("content")
            .TryGetProperty("application/problem+json", out _));
        Assert.False(paths.TryGetProperty("/", out _));
        var parameters = list.GetProperty("parameters").EnumerateArray()
            .Select(parameter => parameter.GetProperty("name").GetString()).ToArray();
        Assert.Contains("dataInicial", parameters);
        Assert.Contains("dataFinal", parameters);
        Assert.Contains("clienteId", parameters);
        Assert.Contains("situacao", parameters);
        Assert.Contains("page", parameters);
        Assert.Contains("pageSize", parameters);
    }

    private static async Task<PageDto<InvoiceDto>> GetPageAsync(HttpClient client, string query = "")
    {
        using var response = await client.GetAsync("/api/notas-fiscais" + query);
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var page = await response.Content.ReadFromJsonAsync<PageDto<InvoiceDto>>();
        Assert.NotNull(page);
        return page;
    }

    internal static async Task<JsonDocument> AssertProblemAsync(HttpResponseMessage response, HttpStatusCode status)
    {
        Assert.Equal(status, response.StatusCode);
        Assert.Equal("application/problem+json", response.Content.Headers.ContentType?.MediaType);
        var document = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
        Assert.Equal((int)status, document.RootElement.GetProperty("status").GetInt32());
        Assert.False(string.IsNullOrWhiteSpace(document.RootElement.GetProperty("title").GetString()));
        Assert.False(string.IsNullOrWhiteSpace(document.RootElement.GetProperty("traceId").GetString()));
        Assert.Equal(response.RequestMessage!.RequestUri!.AbsolutePath,
            document.RootElement.GetProperty("instance").GetString());
        return document;
    }
}
