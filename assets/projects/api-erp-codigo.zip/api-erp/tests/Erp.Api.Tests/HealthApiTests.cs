using System.Net;
using System.Text.Json;

namespace Erp.Api.Tests;

public sealed class HealthApiTests
{
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task Failed_or_throwing_database_check_returns_503_without_internal_details(bool throwOnCheck)
    {
        using var factory = new UnavailableHealthApiFactory(throwOnCheck);
        using var client = factory.CreateClient();
        using var response = await client.GetAsync("/health");

        Assert.Equal(HttpStatusCode.ServiceUnavailable, response.StatusCode);
        var body = await response.Content.ReadAsStringAsync();
        using var document = JsonDocument.Parse(body);
        Assert.Equal("unavailable", document.RootElement.GetProperty("status").GetString());
        Assert.DoesNotContain(FailingInvoiceRepository.InternalError, body, StringComparison.Ordinal);
        Assert.DoesNotContain(nameof(InvalidOperationException), body, StringComparison.Ordinal);
    }
}
