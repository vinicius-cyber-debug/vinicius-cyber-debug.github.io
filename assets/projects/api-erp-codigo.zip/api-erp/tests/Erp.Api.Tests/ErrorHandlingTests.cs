using System.Net;

namespace Erp.Api.Tests;

public sealed class ErrorHandlingTests(FailingRepositoryApiFactory factory) : IClassFixture<FailingRepositoryApiFactory>
{
    [Theory]
    [InlineData("/api/notas-fiscais")]
    [InlineData("/api/notas-fiscais/1")]
    [InlineData("/api/clientes")]
    [InlineData("/api/produtos")]
    public async Task Unexpected_repository_failure_returns_a_safe_500_problem(string path)
    {
        using var client = factory.CreateClient();
        using var response = await client.GetAsync(path);
        using var problem = await InvoiceApiTests.AssertProblemAsync(response, HttpStatusCode.InternalServerError);
        var body = problem.RootElement.GetRawText();

        Assert.DoesNotContain(FailingInvoiceRepository.InternalError, body, StringComparison.Ordinal);
        Assert.DoesNotContain(nameof(InvalidOperationException), body, StringComparison.Ordinal);
        Assert.DoesNotContain("stackTrace", body, StringComparison.OrdinalIgnoreCase);
    }
}
