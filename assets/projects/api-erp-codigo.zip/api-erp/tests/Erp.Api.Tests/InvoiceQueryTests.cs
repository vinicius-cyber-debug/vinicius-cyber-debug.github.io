using Erp.Application;

namespace Erp.Api.Tests;

public sealed class InvoiceQueryTests
{
    [Fact]
    public void No_parameters_use_documented_defaults()
    {
        var filter = InvoiceQuery.Parse();

        Assert.Null(filter.DataInicial);
        Assert.Null(filter.DataFinal);
        Assert.Null(filter.ClienteId);
        Assert.Null(filter.Situacao);
        Assert.Equal(1, filter.Page);
        Assert.Equal(20, filter.PageSize);
        Assert.Equal(0L, filter.Offset);
    }

    [Fact]
    public void All_filters_are_parsed_and_status_is_case_insensitive()
    {
        var filter = InvoiceQuery.Parse("2026-09-05", "2026-09-05", "2", "AUTORIZADA", "3", "100");

        Assert.Equal(new DateOnly(2026, 9, 5), filter.DataInicial);
        Assert.Equal(new DateOnly(2026, 9, 5), filter.DataFinal);
        Assert.Equal(2, filter.ClienteId);
        Assert.Equal("autorizada", filter.Situacao);
        Assert.Equal(3, filter.Page);
        Assert.Equal(100, filter.PageSize);
        Assert.Equal(200L, filter.Offset);
    }

    [Theory]
    [InlineData("2026-09-05", null)]
    [InlineData(null, "2026-09-05")]
    public void Date_interval_can_have_one_open_boundary(string? start, string? end)
    {
        var filter = InvoiceQuery.Parse(dataInicial: start, dataFinal: end);

        Assert.Equal(start is null, filter.DataInicial is null);
        Assert.Equal(end is null, filter.DataFinal is null);
    }

    [Theory]
    [InlineData("dataInicial", "2026-02-30")]
    [InlineData("dataInicial", "05/09/2026")]
    [InlineData("dataInicial", "2026-09-05T00:00:00")]
    [InlineData("dataInicial", "")]
    [InlineData("dataFinal", "2026-13-01")]
    [InlineData("clienteId", "0")]
    [InlineData("clienteId", "-1")]
    [InlineData("clienteId", "1.5")]
    [InlineData("clienteId", "2147483648")]
    [InlineData("clienteId", " ")]
    [InlineData("situacao", "inexistente")]
    [InlineData("situacao", "")]
    [InlineData("page", "0")]
    [InlineData("page", "-1")]
    [InlineData("page", "abc")]
    [InlineData("page", "2147483648")]
    [InlineData("pageSize", "0")]
    [InlineData("pageSize", "101")]
    [InlineData("pageSize", "2.5")]
    public void Invalid_parameter_has_a_field_specific_error(string field, string value)
    {
        var exception = Assert.Throws<QueryValidationException>(() => ParseField(field, value));

        var error = Assert.Single(exception.Errors);
        Assert.Equal(field, error.Key);
        Assert.All(error.Value, message => Assert.False(string.IsNullOrWhiteSpace(message)));
    }

    [Fact]
    public void Reversed_date_interval_is_rejected()
    {
        var exception = Assert.Throws<QueryValidationException>(() =>
            InvoiceQuery.Parse(dataInicial: "2026-09-06", dataFinal: "2026-09-05"));

        Assert.Contains("dataFinal", exception.Errors.Keys);
    }

    [Fact]
    public void Independent_errors_are_reported_together()
    {
        var exception = Assert.Throws<QueryValidationException>(() =>
            InvoiceQuery.Parse(dataInicial: "bad", clienteId: "0", situacao: "bad", page: "0", pageSize: "101"));

        Assert.Equal(5, exception.Errors.Count);
        Assert.Contains("dataInicial", exception.Errors.Keys);
        Assert.Contains("clienteId", exception.Errors.Keys);
        Assert.Contains("situacao", exception.Errors.Keys);
        Assert.Contains("page", exception.Errors.Keys);
        Assert.Contains("pageSize", exception.Errors.Keys);
    }

    [Fact]
    public void Large_valid_page_uses_a_64_bit_offset()
    {
        var filter = InvoiceQuery.Parse(page: "2147483647", pageSize: "100");

        Assert.Equal(214748364600L, filter.Offset);
    }

    [Theory]
    [InlineData("0")]
    [InlineData("-1")]
    [InlineData("abc")]
    [InlineData("1.5")]
    [InlineData("2147483648")]
    public void Invalid_detail_id_is_rejected(string id)
    {
        var exception = Assert.Throws<QueryValidationException>(() => InvoiceQuery.ParseId(id));

        Assert.Contains("id", exception.Errors.Keys);
    }

    [Fact]
    public void Valid_detail_id_is_accepted() => Assert.Equal(48, InvoiceQuery.ParseId("48"));

    private static InvoiceFilter ParseField(string field, string value) => field switch
    {
        "dataInicial" => InvoiceQuery.Parse(dataInicial: value),
        "dataFinal" => InvoiceQuery.Parse(dataFinal: value),
        "clienteId" => InvoiceQuery.Parse(clienteId: value),
        "situacao" => InvoiceQuery.Parse(situacao: value),
        "page" => InvoiceQuery.Parse(page: value),
        "pageSize" => InvoiceQuery.Parse(pageSize: value),
        _ => throw new ArgumentOutOfRangeException(nameof(field))
    };
}
