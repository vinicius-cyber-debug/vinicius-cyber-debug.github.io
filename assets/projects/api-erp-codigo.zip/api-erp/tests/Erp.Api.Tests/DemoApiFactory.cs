using Erp.Application;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace Erp.Api.Tests;

public class DemoApiFactory : WebApplicationFactory<Program>
{
    private readonly string _directory = Path.Combine(Path.GetTempPath(), "erp-api-tests", Guid.NewGuid().ToString("N"));

    public DemoApiFactory() => Directory.CreateDirectory(_directory);

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Development");
        var settings = new Dictionary<string, string?>
        {
            ["Database:Provider"] = "Sqlite",
            ["Database:ConnectionString"] = $"Data Source={Path.Combine(_directory, "test.db")};Pooling=False",
            ["Database:SeedDemo"] = "true"
        };
        foreach (var setting in settings)
            builder.UseSetting(setting.Key, setting.Value);
        builder.ConfigureAppConfiguration((_, configuration) => configuration.AddInMemoryCollection(settings));
    }

    protected override void Dispose(bool disposing)
    {
        base.Dispose(disposing);
        if (disposing && Directory.Exists(_directory))
            Directory.Delete(_directory, recursive: true);
    }
}

public sealed class FailingRepositoryApiFactory : DemoApiFactory
{
    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        base.ConfigureWebHost(builder);
        builder.ConfigureServices(services =>
        {
            services.RemoveAll<IInvoiceRepository>();
            services.AddSingleton<IInvoiceRepository, FailingInvoiceRepository>();
        });
    }
}

internal sealed class FailingInvoiceRepository : IInvoiceRepository
{
    public const string InternalError = "internal-database-password-do-not-disclose";
    public bool IsHealthy { get; init; } = true;
    public bool ThrowHealthError { get; init; }

    public Task<PageDto<InvoiceDto>> ListAsync(InvoiceFilter filter, CancellationToken cancellationToken) =>
        Task.FromException<PageDto<InvoiceDto>>(new InvalidOperationException(InternalError));

    public Task<InvoiceDetailDto?> GetAsync(int id, CancellationToken cancellationToken) =>
        Task.FromException<InvoiceDetailDto?>(new InvalidOperationException(InternalError));

    public Task<IReadOnlyList<CustomerDto>> CustomersAsync(CancellationToken cancellationToken) =>
        Task.FromException<IReadOnlyList<CustomerDto>>(new InvalidOperationException(InternalError));

    public Task<IReadOnlyList<ProductDto>> ProductsAsync(CancellationToken cancellationToken) =>
        Task.FromException<IReadOnlyList<ProductDto>>(new InvalidOperationException(InternalError));

    public Task<bool> IsAvailableAsync(CancellationToken cancellationToken) => ThrowHealthError
        ? Task.FromException<bool>(new InvalidOperationException(InternalError))
        : Task.FromResult(IsHealthy);
}

public sealed class UnavailableHealthApiFactory(bool throwOnHealthCheck) : DemoApiFactory
{
    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        base.ConfigureWebHost(builder);
        builder.ConfigureServices(services =>
        {
            services.RemoveAll<IInvoiceRepository>();
            services.AddSingleton<IInvoiceRepository>(new FailingInvoiceRepository
            {
                IsHealthy = false,
                ThrowHealthError = throwOnHealthCheck
            });
        });
    }
}
