using Dapper;
using Erp.Application;
using Erp.Infrastructure;

namespace Erp.Api.Tests;

public sealed class DatabaseBehaviorTests
{
    [Fact]
    public async Task Changing_current_product_price_keeps_invoice_snapshot_and_totals()
    {
        using var database = new IsolatedDatabase();
        await database.Initializer.InitializeAsync(seedDemo: true);
        var repository = new InvoiceRepository(database.Connections);
        var before = await repository.GetAsync(1, CancellationToken.None);
        Assert.NotNull(before);

        await using (var connection = await database.Connections.OpenAsync(CancellationToken.None))
        {
            var modified = await connection.ExecuteAsync(
                "UPDATE Products SET CurrentPriceCents = @Price WHERE Id = @Id;",
                new { Price = 99999L, Id = 1 });
            Assert.Equal(1, modified);
        }

        var catalog = await repository.ProductsAsync(CancellationToken.None);
        Assert.Equal(999.99m, catalog.Single(product => product.Id == 1).ValorAtual);
        var after = await repository.GetAsync(1, CancellationToken.None);
        Assert.NotNull(after);
        Assert.Equal(before.Total, after.Total);
        Assert.Equal(59.90m, after.Total);
        Assert.Equal(before.Itens.Select(item => item.ValorUnitario), after.Itens.Select(item => item.ValorUnitario));
        Assert.Equal(before.Itens.Select(item => item.ValorTotal), after.Itens.Select(item => item.ValorTotal));
        Assert.Equal(12.50m, after.Itens.Single(item => item.Produto.Id == 1).ValorUnitario);

        var page = await repository.ListAsync(InvoiceQuery.Parse(
            dataInicial: "2026-09-01", dataFinal: "2026-09-01", clienteId: "1"), CancellationToken.None);
        Assert.Equal(59.90m, Assert.Single(page.Items).Total);
    }

    [Fact]
    public async Task Second_seed_preserves_row_counts_and_edited_data()
    {
        using var database = new IsolatedDatabase();
        await database.Initializer.InitializeAsync(seedDemo: true);
        var before = await ReadCountsAsync(database.Connections);
        Assert.Equal(3L, before.Customers);
        Assert.Equal(5L, before.Products);
        Assert.Equal(48L, before.Invoices);
        Assert.Equal(96L, before.Items);

        await using (var connection = await database.Connections.OpenAsync(CancellationToken.None))
        {
            await connection.ExecuteAsync("""
                UPDATE Customers SET Name = @Name WHERE Id = 1;
                UPDATE Products SET CurrentPriceCents = @Price WHERE Id = 1;
                UPDATE Invoices SET Status = 'cancelada' WHERE Id = 1;
                UPDATE InvoiceItems SET Quantity = 3 WHERE InvoiceId = 1 AND Sequence = 1;
                """, new { Name = "Cliente editado", Price = 99999L });
        }

        await database.Initializer.InitializeAsync(seedDemo: true);
        var after = await ReadCountsAsync(database.Connections);
        Assert.Equal(before, after);

        var repository = new InvoiceRepository(database.Connections);
        var invoice = await repository.GetAsync(1, CancellationToken.None);
        Assert.NotNull(invoice);
        Assert.Equal("Cliente editado", invoice.Cliente.Nome);
        Assert.Equal("cancelada", invoice.Situacao);
        Assert.Equal(3, invoice.Itens.Single(item => item.Sequencia == 1).Quantidade);
        Assert.Equal(72.40m, invoice.Total);
        var products = await repository.ProductsAsync(CancellationToken.None);
        Assert.Equal(999.99m, products.Single(product => product.Id == 1).ValorAtual);
    }

    private static async Task<DatabaseCounts> ReadCountsAsync(ConnectionFactory factory)
    {
        await using var connection = await factory.OpenAsync(CancellationToken.None);
        using var result = await connection.QueryMultipleAsync("""
            SELECT COUNT(*) FROM Customers;
            SELECT COUNT(*) FROM Products;
            SELECT COUNT(*) FROM Invoices;
            SELECT COUNT(*) FROM InvoiceItems;
            """);
        return new DatabaseCounts(await result.ReadSingleAsync<long>(), await result.ReadSingleAsync<long>(),
            await result.ReadSingleAsync<long>(), await result.ReadSingleAsync<long>());
    }

    private sealed record DatabaseCounts(long Customers, long Products, long Invoices, long Items);

    private sealed class IsolatedDatabase : IDisposable
    {
        private readonly string _directory = Path.Combine(Path.GetTempPath(), "erp-api-tests", Guid.NewGuid().ToString("N"));

        public IsolatedDatabase()
        {
            Directory.CreateDirectory(_directory);
            Connections = new ConnectionFactory(new DatabaseSettings("Sqlite",
                $"Data Source={Path.Combine(_directory, "database.db")};Pooling=False", true));
            Initializer = new DatabaseInitializer(Connections);
        }

        public ConnectionFactory Connections { get; }
        public DatabaseInitializer Initializer { get; }

        public void Dispose()
        {
            if (Directory.Exists(_directory)) Directory.Delete(_directory, recursive: true);
        }
    }
}
