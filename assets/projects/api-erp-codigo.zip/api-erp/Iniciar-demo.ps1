﻿param([string]$DotnetPath)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'scripts\Resolve-Dotnet.ps1')
$taskDotnet = Resolve-ErpDotnet -DotnetPath $DotnetPath
Push-Location $PSScriptRoot
try {
    Write-Host 'API ERP: http://127.0.0.1:5080/swagger (Ctrl+C para encerrar)'
    & $taskDotnet run --project 'src/Erp.Api/Erp.Api.csproj' --launch-profile demo
    if ($LASTEXITCODE -ne 0) { throw 'A execução da API falhou.' }
} finally { Pop-Location }
