# Validação executada — 9 de outubro de 2026

O primeiro MVP da API ERP foi compilado e executado neste computador com SDK .NET **10.0.401**, runtime **10.0.12**, Windows x64 e banco **SQLite**.

## Testes

Comando executado na versão final:

```powershell
.\Verificar.ps1
```

O script executou `dotnet restore Erp.slnx --locked-mode` e `dotnet test Erp.slnx -c Release --no-restore`.

Resultado observado: **80 aprovados, 0 falhas, 0 ignorados**. A compilação das quatro partes da solução foi concluída com a configuração que trata avisos como erros.

Cobertura de comportamentos: validações de datas, IDs, situação e paginação; parâmetros vazios; filtros isolados e combinados; limites inclusivos de datas; ordenação com empates; páginas sem duplicação, vazias e com offset grande; cliente/produtos/itens e valores; notas canceladas; preservação de preços históricos; seed idempotente; erros 400/404/500; health 200/503; Swagger e tipos de conteúdo dos erros.

Os testes de indisponibilidade e erro 500 usam repositórios de teste. Não representam uma falha real do SQL Server.

## Consultas reais por HTTP

O script de início também foi executado com sucesso e a API abriu em `http://127.0.0.1:5080`. As seguintes respostas foram recebidas da aplicação em execução e salvas sem substituir seus dados por exemplos:

| Evidência | Resultado observado |
| --- | --- |
| [consulta-filtrada.json](consulta-filtrada.json) | 200; filtros de período, cliente 1 e situação autorizada; 8 notas no total; primeira página com IDs 46, 43, 34, 31 e 22 |
| [detalhe-nota-48.json](detalhe-nota-48.json) | 200; cliente 3; dois itens, produtos 3 e 4; total R$ 208,80 |
| [erro-parametro.json](erro-parametro.json) | 400; pageSize 101 rejeitado; erro de campo e traceId |
| [nota-inexistente.json](nota-inexistente.json) | 404; ID 999 sem correspondência |
| [health.json](health.json) | 200; status healthy |
| [openapi.json](openapi.json) | Contrato gerado pela aplicação em execução |

O detalhe da nota 48 também foi executado pela interface do Swagger, que apresentou a resposta 200 e os dados da nota fictícia.

## Capturas do sistema real

[Documentação Swagger](swagger.jpg) e [consulta do detalhe da nota 48](detalhe-nota-48.jpg). As imagens foram capturadas da API em execução no navegador do Codex, na largura disponível do painel.

## Limite desta validação

**SQL Server, Docker e Compose não foram executados.** O adaptador e a configuração estão no código, mas precisam de validação em um ambiente com essa infraestrutura. Não foram realizados testes de carga, implantação pública, autenticação ou integração com ERP real.

Os resultados acima comprovam o fluxo local descrito; não são métricas de produção. Os cinco outros projetos do plano continuam planejados.
