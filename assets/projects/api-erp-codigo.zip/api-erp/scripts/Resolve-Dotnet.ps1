﻿function Resolve-ErpDotnet {
    param([string]$DotnetPath)
    if ($DotnetPath) {
        if (-not (Test-Path -LiteralPath $DotnetPath -PathType Leaf)) { throw 'DotnetPath não existe.' }
        return (Resolve-Path -LiteralPath $DotnetPath).Path
    }
    $taskSystemDotnet = Get-Command dotnet -ErrorAction SilentlyContinue
    if ($taskSystemDotnet) {
        $taskSdks = & $taskSystemDotnet.Source --list-sdks
        if ($taskSdks -match '^10\.') { return $taskSystemDotnet.Source }
    }
    # SDK preparado por Codex nesta sessão, fora do código entregável.
    $taskLocalDotnet = Join-Path $PSScriptRoot '..\..\..\work\dotnet\dotnet.exe'
    if (Test-Path -LiteralPath $taskLocalDotnet -PathType Leaf) {
        $taskResolvedDotnet = (Resolve-Path -LiteralPath $taskLocalDotnet).Path
        $taskWorkDirectory = Split-Path -Parent (Split-Path -Parent $taskResolvedDotnet)
        $env:DOTNET_CLI_HOME = Join-Path $taskWorkDirectory 'dotnet-home'
        $env:NUGET_PACKAGES = Join-Path $taskWorkDirectory 'nuget'
        return $taskResolvedDotnet
    }
    throw 'Instale o SDK .NET 10 ou informe -DotnetPath com o caminho do dotnet.exe.'
}
