﻿param([string]$DotnetPath)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'scripts\Resolve-Dotnet.ps1')
$taskDotnet = Resolve-ErpDotnet -DotnetPath $DotnetPath
Push-Location $PSScriptRoot
try {
    & $taskDotnet restore Erp.slnx --locked-mode
    if ($LASTEXITCODE -ne 0) { throw 'Falha no restore.' }
    & $taskDotnet test Erp.slnx -c Release --no-restore
    if ($LASTEXITCODE -ne 0) { throw 'Falha nos testes.' }
} finally { Pop-Location }
